#include<stdio.h>
#define N 10
void Inputmatrix(int a[][N],int n);
void Transpose(int a[][N],int at[][N],int n);
void Printmatrix(int at[][N],int n);
int main(void){
	int s[N][N],st[N][N],n;
	printf("�������Ľף�");
	scanf("%d",&n);
	Inputmatrix(s,n);
	Transpose(s,st,n);
	printf("�þ����ת�þ���Ϊ��\n");
	Printmatrix(st,n);
	return 0;
}
void Inputmatrix(int a[][N],int n){
	int i,j;
	printf("����%d�׾���\n",n);
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
	}
}
void Transpose(int a[][N],int at[][N],int n){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
		at[j][i]=a[i][j];	
	}
}
void Printmatrix(int at[][N],int n){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			printf("%d\t",at[i][j]);	
		}
		printf("\n");	
	}	
}
