#include<stdio.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>
typedef struct card{
	char suit[9];
	char face[6];	
	}CARD;
void Deal(CARD *wcard);
void Shuffle(CARD *wcard);
void Fill(CARD wcard[],char *wface[],char *wsuit[]);
int main(void){
	char *suit[]={"Spades","Hearts","Cubes","Diamonds"};
	char *face[]={"A","2","3","4","5","6","7","8","9","10","Jack","Queen","King"};
	CARD card[52]; 
	srand(time(NULL));
	Fill(card,face,suit);
	Shuffle(card);
	Deal(card);
	return 0;
}
void Fill(CARD wcard[],char *wface[],char *wsuit[]){
	int i;
	for(i=0;i<52;i++){
		strcpy(wcard[i].suit,wsuit[i/13]);
		strcpy(wcard[i].face,wface[i%13]);
	}
}
void Shuffle(CARD *wcard){
	int i,j;
	CARD temp;
	for(i=0;i<52;i++){
		j=rand()%52;
		temp=wcard[i];
		wcard[i]=wcard[j];
		wcard[j]=temp;
	}
}
void Deal(CARD *wcard){
	int i;
	for(i=0;i<52;i++){
		printf("%9s%9s%c",wcard[i].suit,wcard[i].face,i%2==0?'\n':'\t');
	}
	printf("\n");
}
