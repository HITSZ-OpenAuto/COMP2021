#include<stdio.h>
int Day(int year,int month,int day);
int main(void){
	int year,month,day,sum;
	printf("�����������գ�\n");
	scanf("%d %d %d",&year,&month,&day);
	sum=Day(year,month,day);
	printf("%d��%d��%d���ǵ�%d��",year,month,day,sum);
	return 0;
}
int Day(int year,int month,int day){
	int days[2][12]={{31,28,31,30,31,30,31,31,30,31,30,31},{31,29,31,30,31,30,31,31,30,31,30,31}};
	int sum=day;
	int i;
	if(year%4==0&&year%100!=0||year%400==0){
		for(i=0;i<month-1;i++)
			sum+=days[2][i];
	}else{
	for(i=0;i<month-1;i++)
			sum+=days[1][i];	
	}
	return sum;
}

