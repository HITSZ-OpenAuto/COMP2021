#include<stdio.h>
#define N 40
int ReadScore(int score[]);
int Average(int score[],int n);
int main(void){
	int score[N],aver,n;
	n=ReadScore(score);aver=Average(score,n);
	int i,cnt=0;
	for(i=0;i<n;i++){
		if(score[i]>aver)
		cnt++;
	}
	printf("�ɼ�����ƽ���ֵ�����Ϊ%d",cnt);
	return 0;
}
int ReadScore(int score[]){
	int i=-1;
	do{
		i++;
		printf("����ɼ���");
		scanf("%d",&score[i]); 
	}while(score[i]>=0);
	return i;
}
int Average(int score[],int n){
	int i,sum=0;
	for(i=0;i<n;i++)
	sum+=score[i];
	return n>0?sum/n:-1;
}
