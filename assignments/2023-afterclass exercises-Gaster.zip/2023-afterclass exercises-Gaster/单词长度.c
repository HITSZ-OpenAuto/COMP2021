#include<stdio.h>
#define N 100
int main(void){
	char sentense[N];
	printf("������һ���ı���");
	gets(sentense);
	int i,j=0,cnt=0,n=0;
	for(i=0;sentense[i]!='.';i++){
	if(sentense[i]==' '|sentense[i]=='.'){
		j=i-n-cnt;
		cnt++;
		n+=j;
		printf("%d ",j);
		}
	}
	j=i-n-cnt;
	cnt++;
	n+=j;
	printf("%d",j);
	return 0;
}
