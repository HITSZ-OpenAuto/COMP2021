#include<stdio.h>
#define ROW 7
#define COL 7
int main(void){
	int i,j;
	int arr[ROW][COL]={};
	for(i=0;i<ROW;i++){
		arr[i][0]=1;
		for(j=1;j<=i;j++)
		arr[i][j]=arr[i-1][j-1]+arr[i-1][j];
		}
	for(i=0;i<ROW;i++){
		for(j=0;j<=i;j++)
		printf("%5d",arr[i][j]);
		printf("\n");
	}
	return 0;
}
