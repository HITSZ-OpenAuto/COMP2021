#include<stdio.h>
#define N 10
void DataSort(int a[],int n);
int main(void){
	int i,n,a[N];
	printf("��������n:");
	scanf("%d",&n);
	printf("����%d�����֣�",n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	DataSort(a,n);
	for(i=0;i<n;i++)
	printf("%4d",a[i]);
	printf("\n");
	return 0;
}
void DataSort(int a[],int n){
	int i,j,temp;
	for(i=0;i<n-1;i++){
		for(j=1;j<n-i;j++){
			if(a[j]<a[j-1]){
				temp=a[j];
				a[j]=a[j-1];
				a[j-1]=temp;
			}
		}
	}
}
