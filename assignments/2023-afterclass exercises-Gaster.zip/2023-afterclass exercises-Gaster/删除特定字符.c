#include<stdio.h>
#define N 120
void Delete(char s[],char c);
int main(void){
	char str[N]={0},ch;
	printf("�����ַ�����");
	gets(str);
	printf("��ɾ�����ַ���");
	ch=getchar();
	Delete(str,ch);
	printf("%s\n",str);
	return 0;
}
void Delete(char s[N],char c){
	int i=0,j=0;
	while(s[i]!='\0'){
		if(s[j]!=c){
			if(i!=j)
			s[i]=s[j];
			i++;
			j++;
		}
		if(s[j]==c)
		j++;
	}
	s[i]='\0';
}
