#include<stdio.h>
#define N 50
void Reverse(char*a,char*b);
int main(void){
	char str[N]={0},cop[N]={0};
	printf("�������ַ�����");
	gets(str);
	Reverse(str,cop);
	puts(cop);
	return 0;
}
void Reverse(char*a,char*b){
	char ch;
	ch=a[0];
	while(*a!='\0')
	a++;
	a--;
	while(*a!=ch){
		*b=*a;
		a--;
		b++;
	}
	*b=ch;
}
