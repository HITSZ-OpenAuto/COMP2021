#include<stdio.h>
int main(void){
	typedef struct data{
		int year;
		int month;
		int day;
	}DATA;
	typedef struct state{
		char collage[20];
		char title[20];
		char duty[20];
	}STATE;
	struct student{
		char Name[10];
		char Sex;
		DATA birthday;
		STATE occupation;
	};
	
	return 0;
}
