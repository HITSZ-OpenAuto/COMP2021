#include<stdio.h>
int main(void)
{
	int i,a,b,c,d;
	for(i=100;i<=999;i++){
		a=i/100;
		b=i%100/10;
		c=i%10;
		d=a*a*a+b*b*b+c*c*c;
		if(d==i){
			printf("%d\n",i);
		}
	}
	return 0;
}
