#include<stdio.h>
int main(void){
	int year;
	double input,output;
	printf("�����뱾������ޣ�");
	scanf("%lf %d",&input,&year);
	switch(year){
		case 1:
			output=input*(1+0.0225);
			break;
		case 2:
			output=input*(1+0.0243)*(1+0.0243);
			break;
		case 3:
			output=input*(1+0.0270)*(1+0.0270)*(1+0.0270);
			break;
		case 5:
			output=input*(1+0.0288)*(1+0.0288)*(1+0.0288)*(1+0.0288)*(1+0.0288);
			break;
		case 8:
			output=input*(1+0.0300)*(1+0.0288)*(1+0.0288)*(1+0.0288)*(1+0.0288)*(1+0.0288)*(1+0.0288)*(1+0.0288);
			break;
	}
	printf("����ʱ������=%f",output);
	return 0;
}
