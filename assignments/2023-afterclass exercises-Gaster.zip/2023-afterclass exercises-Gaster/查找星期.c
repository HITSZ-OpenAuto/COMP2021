#include<stdio.h>
#include<string.h>
int main(void){
	int i,pos;
	int findflag=0;
	char input[10];
	char week[7][10]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	printf("���������ڵ�Ӣ�ģ�"); 
	scanf("%s",input);
	for(i=0;i<7&&!findflag;i++){
		if(strcmp(input,week[i])==0){
			pos=i;
			findflag=1;
		}		
	}
	if(findflag)
	printf("%s��%d\n",input,pos);
	else
	printf("�������\n");
	return 0;
}
