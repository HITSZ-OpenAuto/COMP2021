#include<stdio.h>
#include<stdlib.h>
void F1(void);
void F2(void);
int main(void){
	printf("1.year/month/day->yearDay\n2.yearDay->year/month/day\n3.Exit\n");
	printf("Please enter your choice:");
	int s;
	scanf("%d",&s);
	switch(s){
		case 1:
			F1();
			break;
		case 2:
			F2();
			break;
		case 3:
			exit(1);
			break;
		default:;
	}
	return 0;
}
void F1(void){
	int year,month,day,sum;
	printf("�����������գ�\n");
	scanf("%d %d %d",&year,&month,&day);
	int days[2][12]={{31,28,31,30,31,30,31,31,30,31,30,31},{31,29,31,30,31,30,31,31,30,31,30,31}};
	sum=day;
	int i;
	if(year%4==0&&year%100!=0||year%400==0){
		for(i=0;i<month-1;i++)
			sum+=days[2][i];
	}else{
	for(i=0;i<month-1;i++)
			sum+=days[1][i];	
	}
	printf("%d��%d��%d���ǵ�%d��",year,month,day,sum);
}
void F2(void){
	int year,yearday,Month,Day;
	printf("��������ݣ�");
	scanf("%d",&year);
	printf("���������ĵڼ��죺");
	scanf("%d",&yearday);
	int days[2][12]={{31,28,31,30,31,30,31,31,30,31,30,31},{31,29,31,30,31,30,31,31,30,31,30,31}};
	int i=0;
	if(year%4==0&&year%100!=0||year%400==0){
	while(yearday>days[2][i]){
		yearday-=days[2][i];
		i++;
		}
	}else{
	while(yearday>days[1][i]){
		yearday-=days[1][i];
		i++;
		}
	}
	Month=i+1;
	Day=yearday;
	printf("\n%d��%d��",Month,Day);
}
