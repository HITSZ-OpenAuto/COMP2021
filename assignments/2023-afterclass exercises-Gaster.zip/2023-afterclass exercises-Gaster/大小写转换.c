#include<stdio.h>
#define N 32
int main(void){
	char ch;
	printf("����һ���ַ���");
	ch=getchar();
	if(ch>='A'&&ch<='Z'){
		ch+=32;
		printf("%c,%d",ch,ch);
	}
	else if(ch>='a'&&ch<='z'){
		ch-=32;
		printf("%c,%d",ch,ch);
	}
	else
	printf("%d",ch);
	return 0;
}
