#include<stdio.h>
#define N 10
void ReadMatrix(int n,int matrix[N][N]){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
		scanf("%d",&matrix[i][j]);
	}
}
int SumMatrix(int n,int matrix[N][N]){
		int sum=0,i,j;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
		if(i==j||i+j==n-1)
		sum+=matrix[i][j];	
		}
	}
	return sum;
}
int main(void){
	int n;
	printf("���������Ľף�");
	scanf("%d",&n);
	int matrix[n][n];
	ReadMatrix(n,matrix);
	int sum;
	sum=SumMatrix(n,matrix);
	printf("�þ���Խ����ϵ�Ԫ��֮��=%d",sum);
	return 0;
}
