#include<stdio.h>
#include<math.h>
int main(void){
	int IsPrime;
	printf("������һ����������");
	scanf("%d",&IsPrime);
	int i;
	for(i=2;i<(sqrt(IsPrime));i++){
		if(IsPrime%i==0){
			printf("%d is not a prime number\n",IsPrime);
			goto OUT;
		}else
		continue;
	}
	printf("%d is a prime number\n",IsPrime);
OUT:	
	return 0;
}
