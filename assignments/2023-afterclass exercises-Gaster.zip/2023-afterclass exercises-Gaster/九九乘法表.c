#include<stdio.h>
int main(void){
	int m;
	for(m=1;m<=9;m++)
	printf("%4d",m);
	printf("\n");
	int n;
	for(n=1;n<=9;n++)
	printf("   -");
	printf("\n");
	int i,j=1;
	for(i=1;i<=9;i++){
		for(j=1;j<=i;j++){
			printf("%4d",i*j);
		}
		printf("\n");
	}
	return 0;
}
