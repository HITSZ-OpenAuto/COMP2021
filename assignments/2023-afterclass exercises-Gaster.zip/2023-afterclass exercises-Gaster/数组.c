#include<stdio.h>
#define N 10
#define M 10
void Inputarray(int a[][N],int m,int n);
int FindMax(int*p,int m,int n,int*pRow,int*pCol)
int main(void){
	int s[M][N],st[N][M],m,n;
	printf("���������к��У�");
	scanf("%d %d",&m,&n);
	Inputmatrix(s,m,n);
	Transpose(s,st,m,n);
	printf("�þ����ת�þ���Ϊ��\n");
	Printmatrix(st,n,m);
	return 0;
}
void Inputmatrix(int a[][N],int m,int n){
	int i,j;
	printf("����%d*%d�׾���\n",m,n);
	for(i=0;i<m;i++){
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
	}
}
void Transpose(int a[][N],int at[][M],int m,int n){
	int i,j;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++)
		at[j][i]=a[i][j];	
	}
}
void Printmatrix(int at[][M],int n,int m){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			printf("%d\t",at[i][j]);	
		}
		printf("\n");	
	}	
}
