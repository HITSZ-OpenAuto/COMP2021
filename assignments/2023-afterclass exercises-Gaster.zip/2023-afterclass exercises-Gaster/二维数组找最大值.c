#include<stdio.h>
#define M 10
#define N 10
void InputArray(int *p,int m,int n){
	printf("input %d*%d array:\n",m,n);
	int i,j;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			scanf("%d",&p[i*n+j]);
		}
	}
}
int FindMax(int *p,int m,int n,int *pRow,int *pCol){
	int max,i,j;
	max=p[0];
	*pRow=1;
	*pCol=1;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			if(max<p[i*n+j]){
				max=p[i*n+j];
				*pRow=i+1;
				*pCol=j+1;
			}
		}
	}
	return max;
}
int main(void){
	int m,n;
	printf("input m,n:");
	scanf("%d,%d",&m,&n);
	int a[M][N];
	InputArray(*a,m,n);
	int max,row,col;
	max=FindMax(*a,m,n,&row,&col);
	printf("max=%d,row=%d,col=%d",max,row,col);
	return 0;
}
