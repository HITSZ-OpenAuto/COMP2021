#include<stdio.h>
void monthday(int year,int yearday,int*pMonth,int*pDay);
int main(void){
	int year,yearday,pMonth,pDay;
	printf("��������ݣ�");
	scanf("%d",&year);
	printf("���������ĵڼ��죺");
	scanf("%d",&yearday);
	monthday(year,yearday,&pMonth,&pDay);
	printf("\n%d��%d��",pMonth,pDay);
	return 0;
}
void monthday(int year,int yearday,int*pMonth,int*pDay){
	int days[2][12]={{31,28,31,30,31,30,31,31,30,31,30,31},{31,29,31,30,31,30,31,31,30,31,30,31}};
	int i=0;
	if(year%4==0&&year%100!=0||year%400==0){
	while(yearday>days[2][i]){
		yearday-=days[2][i];
		i++;
		}
	}else{
	while(yearday>days[1][i]){
		yearday-=days[1][i];
		i++;
		}
	}
	*pMonth=i+1;
	*pDay=yearday;
}
