#include<stdio.h>
#include<string.h> 
int main(void){
	typedef struct candiadate{
		char name[6];
		int vote;
	}CAND;
	CAND cand1={"zhang",0},cand2={"li",0},cand3={"wang",0};
	int i,j=0,m,cancel=0;
	char k[6]={0};
	for(i=1;i<=10;i++){
		printf("������ͶƱ����");
		scanf("%s",k);
		if(strcmp(k,"zhang")==0)
		j=1;
		else if(strcmp(k,"li")==0)
		j=2;
		else if(strcmp(k,"wang")==0)
		j=3;
		else
		cancel++;
		switch(j){
			case 1:cand1.vote++;
			break;
			case 2:cand2.vote++;
			break;
			case 3:cand3.vote++;
			break;
		}
		j=0;
		for(m=0;m<6;m++)
		k[m]=0;	
	}	
	printf("%s %d\n",cand1.name,cand1.vote);
	printf("%s %d\n",cand2.name,cand2.vote);
	printf("%s %d\n",cand3.name,cand3.vote);
	printf("invalidated ticket=%d",cancel);
	return 0;
}
