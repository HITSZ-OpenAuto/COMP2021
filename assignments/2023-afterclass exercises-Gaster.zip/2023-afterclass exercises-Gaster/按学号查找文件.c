#include<stdio.h>
#include<stdlib.h>
#define N 30
typedef struct date{
	int year;
	int month;
	int day;
}DATE;
typedef struct student{
	long ID;
	char name[10];
	char sex;
	DATE birthday;
	int score[4];
	float aver;
}STUDENT;
int SearchNuminFile(char fileName[],long key);
int main(void){
	int n;
	long key;
	printf("Input the searching ID:");
	scanf("%d",&key);
	n=SearchNuminFile("student.txt",key);
	if(n!=-1)
	printf("Record number is %d.\n",n);
	else
	printf("Not found.\n");
	return 0;
} 
int SearchNuminFile(char fileName[],long key){
	FILE *fp;
	STUDENT stu[N];
	int i,j;
	if((fp=fopen(fileName,"rb"))==NULL){
		printf("Failure to open %s!\n",fileName);
		exit(0);
	}
	for(i=0;!feof(fp);i++){
		fread(&stu[i],sizeof(STUDENT),1,fp);
		if(key==stu[i].ID){
			printf("%101d%8s%3c%6d/%02d/%02d",stu[i].ID,stu[i].name,stu[i].sex,stu[i].birthday.year,stu[i].birthday.month,stu[i].birthday.day);
			for(j=0;j<4;j++)
			printf("%4d",stu[i].score[j]);
			printf("%6.1f\n",stu[i].aver);
			fclose(fp);
			return i+1;
		}
	}
	fclose(fp);
	return -1;
}
