#include<stdio.h>
#define N 80
int CopyFile(const char*arcName,const char*dstName);
int main(void){
	char srcFilename[N];
	char dstFilename[N];
	printf("Input source filename:");
	scanf("%s",srcFilename);
	printf("Input destination filename:");
	scanf("%s",dstFilename);
	if(CopyFile(srcFilename,dstFilename))
	printf("Copy succeed!\n");
	else
	printf("Copy failed!\n");
	return 0;	
} 
int CopyFile(const char*srcName,const char*dstName){
	FILE*fpsrc=NULL,*fpdst=NULL;
	int ch,rval=1;
	if((fpsrc=fopen(srcName,"r"))==NULL)goto ERROR;
	if((fpdst=fopen(dstName,"w"))==NULL)goto ERROR;
	while((ch=fgetc(fpsrc))!=EOF){
		if(fputc(ch,fpdst)==EOF)goto ERROR;
	}
	fflush(fpdst);
	goto EXIT;
ERROR:
	rval=0;
EXIT:
	if(fpsrc!=NULL)fclose(fpsrc);
	if(fpdst!=NULL)fclose(fpdst);
	return rval;
}
