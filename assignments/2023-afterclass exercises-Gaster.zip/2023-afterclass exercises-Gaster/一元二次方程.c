#include<stdio.h>
#include<math.h>
int main(void)
{
	double a,b,c,x1,x2,d;
	scanf("%lf,%lf,%lf",&a,&b,&c);
	d=sqrt(b*b-4*a*c);
	x1=(-b+d)/(2*a);
	x2=(-b-d)/(2*a);
	printf("x1=%f,x2=%f",x1,x2);
	return 0;
}
