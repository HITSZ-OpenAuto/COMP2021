#include<stdio.h>
#include<stdlib.h>
#define SIZE 51
int main(void){
	int i,j,k,n,data[SIZE]={0};
	int index=1;
	scanf("%d",&n);
	data[1]=1;
	for(i=1;i<=n;i++){
		for(j=1;j<=index;j++)
		data[j]=data[j]*i;
		for(k=1;k<index;k++){
			if(data[k]>10){
				data[k+1]+=data[k]/10;
				data[k]%=10;
			}
		}
		while(data[index]>=10&&index<=SIZE-1){
			data[index+1]=data[index]/10;
			data[index]=data[index]%10;
			index++;
		}
		if(index<=SIZE-1){
			printf("%d!=",i);
			for(j=index;j>=1;j--)
			printf("%d",data[j]);
			printf("\n");
		}else
		printf("�����洢���ޣ�\n"); 
	}
	return 0;
}
