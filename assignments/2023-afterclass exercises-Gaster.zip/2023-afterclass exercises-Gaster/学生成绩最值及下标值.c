#include<stdio.h>
#include<stdlib.h>
void InputScore(int *p,int m,int n){
	
	int i,j;
	for(i=0;i<m;i++){
		printf("�����%d�༶�ĳɼ�:\n",i+1);
		for(j=0;j<n;j++){	
			scanf("%d",&p[i*n+j]);
		}
	}
}
int FindMax(int *p,int m,int n,int *pRow,int *pCol){
	int max,i,j;
	max=p[0];
	*pRow=1;
	*pCol=1;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			if(max<p[i*n+j]){
				max=p[i*n+j];
				*pRow=i+1;
				*pCol=j+1;
			}
		}
	}
	return max;
}
int main(void){
	int *p=NULL,m,n;
	printf("�༶��:");
	scanf("%d",&m);
	printf("ѧ����:");
	scanf("%d",&n);
	p=(int*)calloc(m*n,sizeof(int));
	if(p==NULL){
		printf("û���㹻���ڴ棡\n");
		exit(1);
	}
	InputScore(p,m,n);
	int max,Class,num;
	max=FindMax(p,m,n,&Class,&num);
	printf("max=%d,Class=%d,num=%d",max,Class,num);
	free(p);
	return 0;
}
