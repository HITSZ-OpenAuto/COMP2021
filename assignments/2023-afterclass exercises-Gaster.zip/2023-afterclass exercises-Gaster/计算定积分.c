#include<stdio.h>
float Integral(float(*f)(float),float a,float b){
	float s,h;
	int n=224,i;
	s=((*f)(a)+(*f)(b))/2;
	h=(b-a)/n;
	for(i=1;i<n;i++){
		s+=(*f)(a+i*h);
	}
	return s*h;
}
float F1(float x){
	return 1+x*x;
} 
float F2(float x){
	return x/(1+x*x); 
}
int main(void){
	float y1,y2;
	y1=Integral(F1,0,1);
	y2=Integral(F2,0,3);
	printf("y1=%f\ny2=%f\n",y1,y2);
	return 0;
}
