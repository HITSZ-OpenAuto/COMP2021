#include<stdio.h>

int main(void)
{
	printf("Number:2023312909\nName:�ų���\nExperiment No.1 - Program No.2");
	int i,j=1;
	for(i=1;i<=9;i++){
		for(j=1;j<=i;j++){
			printf("%4d",i*j);
		}
		printf("\n");
	}
	return 0;
}
